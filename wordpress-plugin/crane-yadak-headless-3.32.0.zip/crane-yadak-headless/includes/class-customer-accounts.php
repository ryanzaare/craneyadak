<?php
/**
 * حساب کاربری مشتری — ایست ۶ در docs/backlog.md.
 *
 * ---------------------------------------------------------------------------
 * چرا کاربران بومی وردپرس، نه CPT سفارشی
 *
 * هش رمز عبور، جدول کاربران و گردش «فراموشی رمز» را خودِ وردپرس امن و
 * تست‌شده می‌دهد. ساختن این‌ها از نو دقیقاً همان «فنجان یک‌بارمصرف»ای است
 * که این پروژه همیشه از آن پرهیز کرده. فقط لایه‌ی روی آن — صدور توکن
 * برای فرانت‌اند استاتیک — مال ما است.
 *
 * چرا توکن سفارشی، نه یک افزونه‌ی JWT
 *
 * سایت استاتیک است، پس session سمت سرور وجود ندارد و فرانت‌اند باید
 * ورودش را با چیزی جدا از کوکی نگه دارد. یک افزونه‌ی JWT این را می‌دهد،
 * ولی یک وابستگی تازه است برای کاری که دو تابع کوچک حل می‌کند: توکن
 * تصادفی، هش‌شده در متای کاربر، با انقضا. همان فلسفه‌ی «دو
 * wp_remote_post() کافی است» در ایست ۲.
 *
 * چرا هش توکن در *نام* متا، نه در مقدارش
 *
 * برگرداندن کاربر از روی توکن باید سریع باشد. جدول wp_usermeta روی
 * meta_key ایندکس دارد، نه meta_value؛ پس اگر هش را کلید متا کنیم
 * (`_cyh_token_<hash>`)، پیداکردن صاحب توکن یک get_users با meta_key
 * دقیق است — همان الگویی که Application Passwords خودِ وردپرس هم
 * استفاده می‌کند. اگر هش را مقدار می‌گذاشتیم، هر بررسی توکن یک اسکن
 * کامل جدول متا می‌شد.
 * ---------------------------------------------------------------------------
 *
 * @package CraneYadakHeadless
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const CYH_CUSTOMER_ROLE       = 'crane_customer';
const CYH_TOKEN_TTL           = 30 * DAY_IN_SECONDS;
const CYH_PASSWORD_RESET_TTL  = HOUR_IN_SECONDS;
const CYH_TOKEN_META_PREFIX   = '_cyh_token_';
const CYH_RESET_HASH_META     = '_cyh_pwreset_hash';
const CYH_RESET_EXPIRY_META   = '_cyh_pwreset_expires';

/* =========================================================================
   ۰) نقش
   ========================================================================= */
/**
 * ⚠️ `add_role` فقط هنگام فعال‌سازی افزونه اجرا می‌شود (کامنت بالای
 * `cyh_activate()` در فایل اصلی). یعنی نصب‌های از قبل فعال — مثل همین
 * سایت در لحظه‌ی نوشتن این کد — این نقش تازه را با overwrite صرف فایل‌ها
 * نمی‌گیرند. `cyh_maybe_reregister_roles()` پایین همین فایل این را با
 * یک نگهبان نسخه روی `admin_init` جبران می‌کند.
 */
function cyh_register_customer_role() {
	add_role(
		CYH_CUSTOMER_ROLE,
		'مشتری',
		[
			'read' => true,
		]
	);
}

/**
 * نگهبان ارتقا — نقش‌ها را برای نصب‌های موجود هم به‌روز نگه می‌دارد.
 *
 * ⚠️ بدون این، افزودن هر نقش تازه در نسخه‌های بعدی فقط روی نصب‌های
 * *تازه* اثر می‌کرد، نه روی سایتی که از نسخه‌ی قبل‌تر فعال بوده — دقیقاً
 * همان «شکست بی‌صدا» که این پروژه چند بار به آن برخورده: کد درست است،
 * ولی هیچ‌وقت روی سایت واقعی اجرا نمی‌شود.
 */
function cyh_maybe_reregister_roles() {
	if ( get_option( 'cyh_roles_version' ) === CYH_VERSION ) {
		return;
	}
	cyh_register_customer_role();
	if ( function_exists( 'cyh_register_roles' ) ) {
		cyh_register_roles(); // نقش‌های سازمانی — class-community.php
	}
	update_option( 'cyh_roles_version', CYH_VERSION );
}
add_action( 'admin_init', 'cyh_maybe_reregister_roles' );

/* =========================================================================
   ۱) توکن — صدور، تأیید، ابطال
   ========================================================================= */

/** توکن خام را برای مشتری صادر می‌کند و هش آن را در متای کاربر ذخیره می‌کند. */
function cyh_customer_issue_token( $user_id ) {
	$token = bin2hex( wp_generate_password( 64, false, false ) );
	// ⚠️ wp_generate_password طول را به‌صورت *کاراکتر* می‌گیرد، نه بایت؛
	// hex کردنش تصادفی‌بودن را کم نمی‌کند چون خودِ کاراکترها از یک
	// الفبای گسترده‌اند، فقط طول رشته را دو برابر می‌کند. طول واقعی
	// اهمیتی ندارد — فقط باید به‌اندازه‌ی کافی حدس‌ناپذیر باشد.
	$hash = hash( 'sha256', $token );
	update_user_meta( $user_id, CYH_TOKEN_META_PREFIX . $hash, time() + CYH_TOKEN_TTL );
	return $token;
}

/** توکن خام از هدر → شناسه‌ی کاربر، یا false اگر نامعتبر/منقضی. */
function cyh_customer_verify_token( $token ) {
	$token = trim( (string) $token );
	if ( '' === $token ) {
		return false;
	}
	$hash  = hash( 'sha256', $token );
	$users = get_users(
		[
			'meta_key'   => CYH_TOKEN_META_PREFIX . $hash,
			'number'     => 1,
			'fields'     => 'ID',
		]
	);
	if ( empty( $users ) ) {
		return false;
	}
	$user_id = (int) $users[0];
	$expires = (int) get_user_meta( $user_id, CYH_TOKEN_META_PREFIX . $hash, true );
	if ( $expires < time() ) {
		delete_user_meta( $user_id, CYH_TOKEN_META_PREFIX . $hash );
		return false;
	}
	return $user_id;
}

/** فقط همین توکن (یک دستگاه/نشست) را باطل می‌کند — بقیه دست‌نخورده می‌مانند. */
function cyh_customer_revoke_token( $token ) {
	$user_id = cyh_customer_verify_token( $token );
	if ( ! $user_id ) {
		return;
	}
	delete_user_meta( $user_id, CYH_TOKEN_META_PREFIX . hash( 'sha256', trim( (string) $token ) ) );
}

/**
 * همه‌ی توکن‌های یک کاربر را باطل می‌کند — بعد از تغییر رمز.
 *
 * ⚠️ بدون این، تغییر رمز فقط رمز را عوض می‌کرد ولی نشست‌های باز (مثلاً
 * روی دستگاهی که گم شده) همچنان معتبر می‌ماندند. تغییر رمز باید یعنی
 * «همه‌جا خارج شو»، نه فقط «از این به بعد رمز تازه لازم است».
 */
function cyh_customer_revoke_all_tokens( $user_id ) {
	foreach ( get_user_meta( $user_id ) as $key => $value ) {
		if ( str_starts_with( $key, CYH_TOKEN_META_PREFIX ) ) {
			delete_user_meta( $user_id, $key );
		}
	}
}

/**
 * توکن خام درخواست — اول هدر X-Crane-Token، بعد Authorization: Bearer.
 *
 * ⚠️ چرا هدر سفارشی اول است: روی بسیاری از هاست‌های اشتراکی (Apache با
 * PHP به‌شکل CGI/FastCGI) هدر Authorization پیش از رسیدن به PHP حذف
 * می‌شود، مگر قاعده‌ای در .htaccess آن را برگرداند. هدرهای X- این
 * مشکل را ندارند. 🔶 این‌که هاست این پروژه Authorization را حذف
 * می‌کند یا نه آزموده نشده؛ هدر سفارشی آن سؤال را بی‌اهمیت می‌کند.
 * Authorization فقط برای سازگاری نگه داشته شد.
 */
function cyh_customer_request_token( $request ) {
	$custom = trim( (string) $request->get_header( 'x-crane-token' ) );
	if ( '' !== $custom ) {
		return $custom;
	}
	$header = trim( (string) $request->get_header( 'authorization' ) );
	return preg_match( '/^Bearer\s+(.+)$/i', $header, $m ) ? trim( $m[1] ) : '';
}

/** توکن درخواست را می‌خواند و کاربر را برمی‌گرداند. */
function cyh_customer_authenticate_request( $request ) {
	$token = cyh_customer_request_token( $request );
	if ( '' === $token ) {
		return new WP_Error( 'cyh_no_token', 'وارد نشده‌اید.', [ 'status' => 401 ] );
	}
	$user_id = cyh_customer_verify_token( $token );
	if ( ! $user_id ) {
		return new WP_Error( 'cyh_bad_token', 'نشست منقضی شده — دوباره وارد شوید.', [ 'status' => 401 ] );
	}
	return $user_id;
}

/* =========================================================================
   ۲) کمک‌کننده‌های اعتبارسنجی
   ========================================================================= */

/** همان الگوی موبایل ایران که فرم تماس استفاده می‌کند (class-rest-contact.php). */
/**
 * سیاست رمز عبور — مشکل را برمی‌گرداند، یا null اگر رمز قابل قبول است.
 *
 * تاریخچه‌ی تصمیم (هر دو از کارفرما):
 *   • نسخه‌ی اول فقط «حداقل ۸ کاراکتر» بود — `12345678` و `password`
 *     از آن رد می‌شدند. قیدهای ۲ تا ۵ اضافه شد.
 *   • یک نسخه‌ی میانی حداقل را ۱۰ کرد؛ کارفرما گفت زیاد است. با وجود
 *     قیدهای ۲ تا ۵، ۸ کافی است — طول تنها قید نیست.
 *
 * قیدها، هرکدام برای یک مشکل مشخص:
 *   ۱) طول ≥ ۸ — mb_strlen، چون حرف فارسی چندبایتی است.
 *   ۲) ارقام فارسی/عربی **ممنوع**، فقط 0-9 انگلیسی. رمز با ارقام فارسی
 *      روی صفحه‌کلید دیگر (یا دستگاه دیگر) عملاً قابل تایپ نیست و کاربر
 *      از حساب خودش بیرون می‌ماند. ⚠️ عمداً به لاتین تبدیل *نمی‌شوند*:
 *      تبدیل یعنی «۱۲۳» و «123» دو رمز یکسان باشند، ولی wp_authenticate
 *      رشته‌ی خام را مقایسه می‌کند و ورود بعدی شکست می‌خورد.
 *   ۳) حداقل یک حرف و یک رقم.
 *   ۴) فهرست سیاه + تکرار یک کاراکتر — اولین حدس‌های هر حمله.
 *   ۵) نام ایمیل داخل رمز نباشد.
 *
 * این تابع تنها مرجع است؛ فرم‌های فرانت‌اند فقط پیامش را نشان می‌دهند.
 */
function cyh_customer_password_problem( $pass, $email = '' ) {
	$pass = (string) $pass;

	if ( mb_strlen( $pass ) < 8 ) {
		return 'رمز عبور باید حداقل ۸ کاراکتر باشد.';
	}

	if ( preg_match( '/[\x{06F0}-\x{06F9}\x{0660}-\x{0669}]/u', $pass ) ) {
		return 'در رمز عبور فقط از اعداد انگلیسی (0-9) استفاده کنید، نه اعداد فارسی.';
	}

	if ( ! preg_match( '/\p{L}/u', $pass ) || ! preg_match( '/[0-9]/', $pass ) ) {
		return 'رمز عبور باید هم حرف داشته باشد و هم عدد.';
	}

	$lower = mb_strtolower( $pass );
	$blocked = [
		'password1', 'password12', 'password123', 'password1234', 'passw0rd',
		'qwerty123', 'qwerty1234', 'qwerty12345', 'abc12345', 'abcd1234',
		'12345678a', 'a12345678', '1q2w3e4r', '1qaz2wsx', 'iloveyou1',
		'admin123', 'admin1234', 'welcome1', 'welcome123', 'test1234',
		'pass1234', 'crane123', 'craneyadak1', 'craneyadak123',
	];
	if ( in_array( $lower, $blocked, true ) ) {
		return 'این رمز عبور بسیار رایج است و به‌راحتی حدس زده می‌شود.';
	}

	// یک کاراکتر تکراری با یک رقم ته آن (aaaaaaaaa1) — طولش گول می‌زند.
	if ( preg_match( '/^(.)\1+\d*$/u', $lower ) ) {
		return 'رمز عبور نباید از تکرار یک کاراکتر ساخته شود.';
	}

	$local = mb_strtolower( (string) strstr( (string) $email, '@', true ) );
	if ( mb_strlen( $local ) >= 4 && false !== mb_strpos( $lower, $local ) ) {
		return 'رمز عبور نباید شامل نام ایمیل شما باشد.';
	}

	return null;
}

function cyh_customer_valid_phone( $digits ) {
	return (bool) preg_match( '/^(0)?9\d{9}$/', $digits );
}

/** 9121234567 و 09121234567 یک شماره‌اند؛ ذخیره همیشه با صفر اول. */
function cyh_customer_phone_canonical( $digits ) {
	return '0' . ltrim( (string) $digits, '0' );
}

/**
 * آیا حساب دیگری (غیر از $except_id) این شماره را دارد؟
 * ⚠️ هر دو شکل با/بدون صفر اول جست‌وجو می‌شود: حساب‌های ساخته‌شده پیش از
 * یکتایی ممکن است بدون صفر ذخیره شده باشند.
 */
function cyh_customer_phone_taken( $phone, $except_id = 0 ) {
	$canonical = cyh_customer_phone_canonical( $phone );
	$found     = get_users(
		[
			'meta_query' => [ // phpcs:ignore WordPress.DB.SlowDBQuery
				[ 'key' => 'cyh_phone', 'value' => [ $canonical, ltrim( $canonical, '0' ) ], 'compare' => 'IN' ],
			],
			'exclude'    => [ (int) $except_id ],
			'number'     => 1,
			'fields'     => 'ID',
		]
	);
	return ! empty( $found );
}

function cyh_customer_profile( $user ) {
	return [
		'id'      => (int) $user->ID,
		'name'    => $user->display_name,
		'email'   => $user->user_email,
		'phone'   => get_user_meta( $user->ID, 'cyh_phone', true ) ?: null,
		'company' => get_user_meta( $user->ID, 'cyh_company', true ) ?: null,
	];
}

/* =========================================================================
   ۳) اندپوینت‌های REST
   ========================================================================= */
function cyh_register_customer_routes() {
	$public = [ 'methods' => 'POST', 'permission_callback' => '__return_true' ];

	register_rest_route( 'crane-yadak/v1', '/account/register', array_merge( $public, [ 'callback' => 'cyh_rest_account_register' ] ) );
	register_rest_route( 'crane-yadak/v1', '/account/login', array_merge( $public, [ 'callback' => 'cyh_rest_account_login' ] ) );
	register_rest_route( 'crane-yadak/v1', '/account/logout', array_merge( $public, [ 'callback' => 'cyh_rest_account_logout' ] ) );
	register_rest_route( 'crane-yadak/v1', '/account/forgot-password', array_merge( $public, [ 'callback' => 'cyh_rest_account_forgot_password' ] ) );
	register_rest_route( 'crane-yadak/v1', '/account/reset-password', array_merge( $public, [ 'callback' => 'cyh_rest_account_reset_password' ] ) );
	register_rest_route(
		'crane-yadak/v1',
		'/account/me',
		[ 'methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => 'cyh_rest_account_me' ]
	);
	register_rest_route(
		'crane-yadak/v1',
		'/account/orders',
		[ 'methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => 'cyh_rest_account_orders' ]
	);
	register_rest_route( 'crane-yadak/v1', '/account/profile', array_merge( $public, [ 'callback' => 'cyh_rest_account_profile' ] ) );
	register_rest_route( 'crane-yadak/v1', '/account/saved-checkout/clear', array_merge( $public, [ 'callback' => 'cyh_rest_account_saved_clear' ] ) );
	register_rest_route( 'crane-yadak/v1', '/account/change-password', array_merge( $public, [ 'callback' => 'cyh_rest_account_change_password' ] ) );
	register_rest_route(
		'crane-yadak/v1',
		'/account/wishlist',
		[
			[ 'methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => 'cyh_rest_account_wishlist_get' ],
			[ 'methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'cyh_rest_account_wishlist_update' ],
		]
	);
}
add_action( 'rest_api_init', 'cyh_register_customer_routes' );

/**
 * ثبت‌نام.
 *
 * ⚠️ ایمیل **اجباری** است، حتی اگر شماره هم داده شود — تصمیم صریح
 * کارفرما (docs/backlog.md، ایست ۶). بدون سرویس پیامک، ایمیل تنها
 * کانالی است که «فراموشی رمز» می‌تواند از آن عبور کند؛ حساب فقط-شماره
 * یعنی حسابی که هرگز نمی‌تواند رمزش را بازیابی کند.
 */
/**
 * ایمیل‌های حساب مشتری (فقط متن ساده — بهترین تحویل‌پذیری؛ لینک‌ها همان نشانی‌های فرانت‌اند).
 *   registered       : خوش‌آمد پس از ثبت‌نام
 *   password_changed : هشدار امنیتی پس از هر تغییر رمز (بازیابی یا تغییر در حساب)
 * ⚠️ شکست ایمیل هرگز عملیات اصلی را رد نمی‌کند: حساب ساخته شده/رمز عوض شده، گفتن «خطا» دروغ است.
 * متن «اگر شما نبودید» عمداً راه عمل می‌دهد (بازیابی رمز)؛ هشدار بدون راه عمل فقط می‌ترساند.
 */
function cyh_customer_notify( $user_id = 0, $kind = '' ) {
	$user = get_userdata( (int) $user_id );
	if ( ! $user || ! is_email( (string) $user->user_email ) ) {
		return false;
	}
	$origin = trailingslashit( cyh_get_frontend_url() );
	$name   = '' !== trim( (string) $user->display_name ) ? trim( (string) $user->display_name ) : 'مشتری گرامی';
	if ( 'registered' === $kind ) {
		$subject = 'به کرین یدک خوش آمدید';
		$body    = "{$name} عزیز،\n\nحساب شما در کرین یدک ساخته شد. از این پس می‌توانید سفارش‌ها و پیش‌فاکتورهایتان را پیگیری کنید و اطلاعات تحویل را ذخیره کنید:\n\n{$origin}account/\n\nاگر این حساب را شما نساخته‌اید، فقط به این پیام پاسخ ندهید و ما را از راه صفحه‌ی تماس مطلع کنید:\n{$origin}contact/";
	} elseif ( 'password_changed' === $kind ) {
		$subject = 'رمز عبور حساب شما تغییر کرد';
		$body    = "{$name} عزیز،\n\nرمز عبور حساب شما در کرین یدک هم‌اکنون تغییر کرد و ورودهای قبلی بسته شدند.\n\nاگر این کار را شما نکرده‌اید، همین حالا از این نشانی رمز را بازیابی کنید و سپس با ما تماس بگیرید:\n{$origin}account/forgot-password\n{$origin}contact/";
	} else {
		return false;
	}
	return (bool) wp_mail( (string) $user->user_email, $subject, $body );
}

function cyh_rest_account_register( $request ) {
	$ip = cyh_client_ip();
	if ( '' !== trim( (string) $request->get_param( 'website' ) ) ) {
		return new WP_Error( 'cyh_spam', 'ارسال نامعتبر.', [ 'status' => 400 ] );
	}
	if ( cyh_is_rate_limited( $ip ) ) {
		return new WP_Error( 'cyh_rate_limited', 'تعداد درخواست‌ها زیاد است. کمی بعد دوباره تلاش کنید.', [ 'status' => 429 ] );
	}

	$name  = sanitize_text_field( (string) $request->get_param( 'name' ) );
	$email = sanitize_email( (string) $request->get_param( 'email' ) );
	$pass  = (string) $request->get_param( 'password' );
	$phone = cyh_to_latin_digits( sanitize_text_field( (string) $request->get_param( 'phone' ) ) );
	$org   = sanitize_text_field( (string) $request->get_param( 'company' ) );

	if ( mb_strlen( $name ) < 2 ) {
		return new WP_Error( 'cyh_bad_name', 'نام را کامل وارد کنید.', [ 'status' => 400 ] );
	}
	if ( ! is_email( $email ) ) {
		return new WP_Error( 'cyh_bad_email', 'ایمیل معتبر نیست.', [ 'status' => 400 ] );
	}
	if ( email_exists( $email ) ) {
		return new WP_Error( 'cyh_email_taken', 'حسابی با این ایمیل قبلاً ساخته شده — وارد شوید.', [ 'status' => 409 ] );
	}
	$pw_problem = cyh_customer_password_problem( $pass, $email );
	if ( null !== $pw_problem ) {
		return new WP_Error( 'cyh_weak_password', $pw_problem, [ 'status' => 400 ] );
	}
	// ⚠️ موبایل اجباری است (تصمیم کارفرما): پشتیبانی و پیگیری سفارش به آن نیاز دارد،
	// و تا سرویس پیامک نیامده تنها راه تماس با مشتری بدون ایمیل است.
	if ( '' === $phone || ! cyh_customer_valid_phone( $phone ) ) {
		return new WP_Error( 'cyh_bad_phone', 'شماره موبایل معتبر لازم است (مثل ۰۹۱۲۱۲۳۴۵۶۷).', [ 'status' => 400 ] );
	}
	// ⚠️ یک شماره = یک حساب (آزمون کارفرما: چند حساب با یک شماره ساخته شد). بدون
	// این، بازیابی رمز با پیامک و «حساب من» به شماره‌ی مشترک گره می‌خورد.
	$phone = cyh_customer_phone_canonical( $phone );
	if ( cyh_customer_phone_taken( $phone ) ) {
		return new WP_Error( 'cyh_phone_taken', 'حسابی با این شماره موبایل قبلاً ساخته شده — وارد شوید یا رمز را بازیابی کنید.', [ 'status' => 409 ] );
	}

	$user_id = wp_insert_user(
		[
			'user_login'   => $email,
			'user_email'   => $email,
			'user_pass'    => $pass,
			'display_name' => $name,
			'role'         => CYH_CUSTOMER_ROLE,
		]
	);
	if ( is_wp_error( $user_id ) ) {
		return new WP_Error( 'cyh_register_failed', 'ثبت‌نام انجام نشد. دوباره تلاش کنید.', [ 'status' => 500 ] );
	}

	update_user_meta( $user_id, 'cyh_phone', $phone );
	if ( '' !== $org ) {
		update_user_meta( $user_id, 'cyh_company', $org );
	}
	cyh_customer_notify( $user_id, 'registered' );

	$token = cyh_customer_issue_token( $user_id );
	return rest_ensure_response(
		[
			'success' => true,
			'token'   => $token,
			'profile' => cyh_customer_profile( get_userdata( $user_id ) ),
		]
	);
}

function cyh_rest_account_login( $request ) {
	$ip = cyh_client_ip();
	if ( cyh_is_rate_limited( $ip ) ) {
		return new WP_Error( 'cyh_rate_limited', 'تعداد تلاش‌ها زیاد است. کمی بعد دوباره تلاش کنید.', [ 'status' => 429 ] );
	}

	$email = sanitize_email( (string) $request->get_param( 'email' ) );
	$pass  = (string) $request->get_param( 'password' );

	$user = wp_authenticate( $email, $pass );
	if ( is_wp_error( $user ) ) {
		// ⚠️ پیام عمداً مبهم است — نمی‌گوید کدام فیلد اشتباه بود، تا
		// حدس‌زدن ایمیل‌های ثبت‌شده روی سایت ممکن نشود.
		return new WP_Error( 'cyh_bad_login', 'ایمیل یا رمز عبور اشتباه است.', [ 'status' => 401 ] );
	}

	$token = cyh_customer_issue_token( $user->ID );
	return rest_ensure_response(
		[
			'success' => true,
			'token'   => $token,
			'profile' => cyh_customer_profile( $user ),
		]
	);
}

function cyh_rest_account_logout( $request ) {
	$token = cyh_customer_request_token( $request );
	if ( '' !== $token ) {
		cyh_customer_revoke_token( $token );
	}
	return rest_ensure_response( [ 'success' => true ] );
}

/**
 * ⚠️ همیشه پاسخ موفق برمی‌گرداند — چه ایمیل وجود داشته باشد چه نه.
 *
 * برگرداندن خطای «این ایمیل ثبت نیست» یعنی هر کسی می‌تواند با امتحان‌
 * کردن ایمیل‌ها بفهمد کدام‌ها روی سایت حساب دارند (User Enumeration).
 * همان دلیلی که هانی‌پات این پروژه هم به ربات پاسخ موفق جعلی می‌دهد.
 */
function cyh_rest_account_forgot_password( $request ) {
	$ip = cyh_client_ip();
	if ( cyh_is_rate_limited( $ip ) ) {
		return new WP_Error( 'cyh_rate_limited', 'تعداد درخواست‌ها زیاد است. کمی بعد دوباره تلاش کنید.', [ 'status' => 429 ] );
	}

	$email = sanitize_email( (string) $request->get_param( 'email' ) );
	$user  = is_email( $email ) ? get_user_by( 'email', $email ) : false;

	if ( $user ) {
		$token = bin2hex( wp_generate_password( 64, false, false ) );
		update_user_meta( $user->ID, CYH_RESET_HASH_META, hash( 'sha256', $token ) );
		update_user_meta( $user->ID, CYH_RESET_EXPIRY_META, time() + CYH_PASSWORD_RESET_TTL );

		$reset_url = trailingslashit( cyh_get_frontend_url() ) . 'account/reset-password?email=' . rawurlencode( $email ) . '&token=' . $token;
		wp_mail(
			$email,
			'بازیابی رمز عبور — کرین یدک',
			"برای تعیین رمز تازه، روی لینک زیر بزنید (تا یک ساعت معتبر است):\n\n{$reset_url}\n\nاگر این درخواست را شما نفرستاده‌اید، این پیام را نادیده بگیرید."
		);
	}

	return rest_ensure_response( [ 'success' => true ] );
}

function cyh_rest_account_reset_password( $request ) {
	$ip = cyh_client_ip();
	if ( cyh_is_rate_limited( $ip ) ) {
		return new WP_Error( 'cyh_rate_limited', 'تعداد تلاش‌ها زیاد است. کمی بعد دوباره تلاش کنید.', [ 'status' => 429 ] );
	}

	$email = sanitize_email( (string) $request->get_param( 'email' ) );
	$token = (string) $request->get_param( 'token' );
	$pass  = (string) $request->get_param( 'password' );

	$user = is_email( $email ) ? get_user_by( 'email', $email ) : false;
	if ( ! $user ) {
		return new WP_Error( 'cyh_bad_reset', 'لینک نامعتبر یا منقضی است.', [ 'status' => 400 ] );
	}

	$stored_hash = get_user_meta( $user->ID, CYH_RESET_HASH_META, true );
	$expires     = (int) get_user_meta( $user->ID, CYH_RESET_EXPIRY_META, true );

	if ( '' === $stored_hash || $expires < time() || ! hash_equals( $stored_hash, hash( 'sha256', $token ) ) ) {
		return new WP_Error( 'cyh_bad_reset', 'لینک نامعتبر یا منقضی است.', [ 'status' => 400 ] );
	}
	$pw_problem = cyh_customer_password_problem( $pass, $email );
	if ( null !== $pw_problem ) {
		return new WP_Error( 'cyh_weak_password', $pw_problem, [ 'status' => 400 ] );
	}

	wp_set_password( $pass, $user->ID );
	delete_user_meta( $user->ID, CYH_RESET_HASH_META );
	delete_user_meta( $user->ID, CYH_RESET_EXPIRY_META );
	// ⚠️ تغییر رمز یعنی «همه‌جا خارج شو» — نشست‌های قبلی باطل می‌شوند.
	cyh_customer_revoke_all_tokens( $user->ID );
	cyh_customer_notify( $user->ID, 'password_changed' );

	return rest_ensure_response( [ 'success' => true ] );
}

function cyh_rest_account_me( $request ) {
	$user_id = cyh_customer_authenticate_request( $request );
	if ( is_wp_error( $user_id ) ) {
		return $user_id;
	}

	/* فهرست کوتاه داشبورد: سفارش‌ها (post_author = کاربر، از ایست ۲ فاز ۴) و
	   هر رکورد دیگری که به این حساب وصل باشد. استعلام مهمان به حساب وصل
	   نیست و اینجا نمی‌آید. جزئیات کامل: /account/orders. */
	$orders = get_posts(
		[
			'post_type'   => 'cyh_quote',
			'author'      => $user_id,
			'post_status' => 'publish',
			'numberposts' => 50,
		]
	);

	return rest_ensure_response(
		[
			'profile' => cyh_customer_profile( get_userdata( $user_id ) ),
			'saved'   => cyh_checkout_saved( (int) $user_id ),
			'orders'  => array_map(
				static function ( $post ) {
					return [
						'code'   => get_post_meta( $post->ID, 'cyh_code', true ),
						'kind'   => get_post_meta( $post->ID, 'cyh_kind', true ) ?: 'quote',
						// سفارش پرداخت‌شده: وضعیت رسیدگی؛ سفارش دیگر: وضعیت پرداخت؛ استعلام: وضعیت استعلام.
						'status' => '' !== (string) get_post_meta( $post->ID, 'cyh_payment', true )
							? ( cyh_order_fulfilment_view( $post->ID )['status'] ?? 'pay_' . (string) get_post_meta( $post->ID, 'cyh_payment', true ) )
							: ( get_post_meta( $post->ID, 'cyh_status', true ) ?: 'new' ),
						'date'   => get_the_date( 'Y-m-d', $post ),
					];
				},
				$orders
			),
		]
	);
}

/**
 * سفارش‌های من — فقط رکوردهای kind=order همین کاربر، تازه‌ترین اول.
 *
 * ⚠️ نمایش بر پایه‌ی post_author است، نه شماره‌ی تلفن یا ایمیل: تطبیق با
 * تلفن یعنی هر کس شماره‌ی دیگری را بنویسد سفارش او را ببیند. سفارش‌ها
 * فقط از مسیر /checkout/pay ساخته می‌شوند که ورود را الزامی می‌کند.
 *
 * وضعیت پرداخت (cyh_payment) تنها وضعیتی است که برای سفارش معنا دارد؛
 * فهرست وضعیت‌های cyh_status (ثبت‌شده/پاسخ داده شده…) مال استعلام است.
 * شماره‌ی پیگیری زرین‌پال فقط برای سفارش پرداخت‌شده برمی‌گردد.
 */
function cyh_rest_account_orders( $request ) {
	$user_id = cyh_customer_authenticate_request( $request );
	if ( is_wp_error( $user_id ) ) {
		return $user_id;
	}

	$labels = [
		'pending' => 'در انتظار پرداخت',
		'paid'    => 'پرداخت‌شده',
		'failed'  => 'ناموفق',
	];
	$posts  = get_posts(
		[
			'post_type'   => 'cyh_quote',
			'author'      => $user_id,
			'post_status' => 'publish',
			'numberposts' => 100,
		]
	);
	$out    = [];
	foreach ( $posts as $post ) {
		if ( 'order' !== get_post_meta( $post->ID, 'cyh_kind', true ) ) {
			continue;
		}
		$payment = (string) get_post_meta( $post->ID, 'cyh_payment', true );
		$payment = isset( $labels[ $payment ] ) ? $payment : 'pending';
		$out[]   = [
			'code'         => (string) get_post_meta( $post->ID, 'cyh_code', true ),
			'date'         => get_the_date( 'Y-m-d', $post ),
			'payment'      => $payment,
			'paymentLabel' => $labels[ $payment ],
			'subtotal'     => (int) get_post_meta( $post->ID, 'cyh_subtotal', true ),
			'vat'          => (int) get_post_meta( $post->ID, 'cyh_vat', true ),
			'total'        => (int) get_post_meta( $post->ID, 'cyh_total', true ),
			'invoice'      => is_array( get_post_meta( $post->ID, 'cyh_invoice', true ) ),
			'shipping'     => (string) get_post_meta( $post->ID, 'cyh_shipping_label', true ),
			'refId'        => 'paid' === $payment ? (string) get_post_meta( $post->ID, 'cyh_ref_id', true ) : '',
			'sandbox'      => (bool) get_post_meta( $post->ID, 'cyh_sandbox', true ),
			// رسیدگی/رهگیری/فاکتور رسمی — فقط سفارش پرداخت‌شده، null وگرنه.
			'fulfilment'   => cyh_order_fulfilment_view( $post->ID ),
			'items'        => array_map(
				static function ( $item ) {
					return [
						'name' => (string) ( $item['name'] ?? '' ),
						'sku'  => (string) ( $item['sku'] ?? '' ),
						'qty'  => (int) ( $item['qty'] ?? 0 ),
						'unit' => (int) ( $item['unit'] ?? 0 ),
					];
				},
				(array) get_post_meta( $post->ID, 'cyh_items', true )
			),
		];
	}
	return rest_ensure_response( [ 'orders' => $out ] );
}

/* =========================================================================
   ۴) تنظیمات حساب
   ========================================================================= */

/**
 * ویرایش نام، موبایل و شرکت.
 *
 * ⚠️ ایمیل اینجا قابل تغییر نیست — عمدی. ایمیل تنها کانال بازیابی رمز
 * است؛ تغییرش بدون تأیید ایمیل تازه یعنی یک غلط تایپی کاربر را برای
 * همیشه از حسابش بیرون می‌گذارد. تأیید ایمیل (backlog، پیشنهاد ۹) تا
 * راه‌اندازی سایت و داشتن سرویس ایمیل کنار گذاشته شد.
 */
function cyh_rest_account_profile( $request ) {
	$user_id = cyh_customer_authenticate_request( $request );
	if ( is_wp_error( $user_id ) ) {
		return $user_id;
	}

	$name  = sanitize_text_field( (string) $request->get_param( 'name' ) );
	$phone = cyh_to_latin_digits( sanitize_text_field( (string) $request->get_param( 'phone' ) ) );
	$org   = sanitize_text_field( (string) $request->get_param( 'company' ) );

	if ( mb_strlen( $name ) < 2 ) {
		return new WP_Error( 'cyh_bad_name', 'نام را کامل وارد کنید.', [ 'status' => 400 ] );
	}
	// ⚠️ حذف شماره ممنوع است (همان قاعده‌ی ثبت‌نام).
	if ( '' === $phone || ! cyh_customer_valid_phone( $phone ) ) {
		return new WP_Error( 'cyh_bad_phone', 'شماره موبایل معتبر لازم است (مثل ۰۹۱۲۱۲۳۴۵۶۷).', [ 'status' => 400 ] );
	}

	$phone = cyh_customer_phone_canonical( $phone );
	if ( cyh_customer_phone_taken( $phone, (int) $user_id ) ) {
		return new WP_Error( 'cyh_phone_taken', 'این شماره موبایل برای حساب دیگری ثبت شده است.', [ 'status' => 409 ] );
	}

	wp_update_user( [ 'ID' => $user_id, 'display_name' => $name ] );
	update_user_meta( $user_id, 'cyh_phone', $phone );
	'' !== $org ? update_user_meta( $user_id, 'cyh_company', $org ) : delete_user_meta( $user_id, 'cyh_company' );

	return rest_ensure_response( [ 'success' => true, 'profile' => cyh_customer_profile( get_userdata( $user_id ) ) ] );
}

/**
 * تغییر رمز با دانستن رمز فعلی.
 *
 * ⚠️ رمز فعلی الزامی است: توکن دزدیده‌شده (مثلاً از مرورگری که کاربر
 * خارج نشده) نباید برای تصاحب دائمی حساب کافی باشد. بعد از تغییر، همه‌ی
 * نشست‌ها باطل و برای همین دستگاه یک توکن تازه صادر می‌شود — کاربری که
 * رمزش را عوض کرده نباید از صفحه‌ای که در آن است بیرون پرت شود.
 */
function cyh_rest_account_change_password( $request ) {
	$user_id = cyh_customer_authenticate_request( $request );
	if ( is_wp_error( $user_id ) ) {
		return $user_id;
	}
	if ( cyh_is_rate_limited( cyh_client_ip() ) ) {
		return new WP_Error( 'cyh_rate_limited', 'تعداد تلاش‌ها زیاد است. کمی بعد دوباره تلاش کنید.', [ 'status' => 429 ] );
	}

	$user    = get_userdata( $user_id );
	$current = (string) $request->get_param( 'current_password' );
	$new     = (string) $request->get_param( 'new_password' );

	if ( is_wp_error( wp_authenticate( $user->user_email, $current ) ) ) {
		return new WP_Error( 'cyh_bad_current_password', 'رمز عبور فعلی اشتباه است.', [ 'status' => 400 ] );
	}
	$pw_problem = cyh_customer_password_problem( $new, $user->user_email );
	if ( null !== $pw_problem ) {
		return new WP_Error( 'cyh_weak_password', $pw_problem, [ 'status' => 400 ] );
	}

	wp_set_password( $new, $user_id );
	cyh_customer_revoke_all_tokens( $user_id );
	cyh_customer_notify( $user_id, 'password_changed' );

	return rest_ensure_response( [ 'success' => true, 'token' => cyh_customer_issue_token( $user_id ) ] );
}

/* =========================================================================
   ۵) علاقه‌مندی‌ها
   =========================================================================
   فهرست اسلاگ محصول در متای کاربر. اسلاگ و نه شناسه، چون فرانت‌اند
   استاتیک محصول را با اسلاگ می‌شناسد (همان دلیل productSlug در
   class-questions.php). */
const CYH_WISHLIST_META = 'cyh_wishlist';
const CYH_WISHLIST_MAX  = 100;

/** محصول منتشرشده با این اسلاگ، یا null. */
function cyh_customer_find_product( $slug ) {
	$found = get_posts(
		[
			'post_type'      => 'product',
			'name'           => $slug,
			'post_status'    => 'publish',
			'posts_per_page' => 1,
		]
	);
	return $found ? $found[0] : null;
}

function cyh_customer_wishlist_slugs( $user_id ) {
	$raw = get_user_meta( $user_id, CYH_WISHLIST_META, true );
	return is_array( $raw ) ? array_values( array_filter( $raw, 'is_string' ) ) : [];
}

/**
 * ⚠️ محصولی که بعد از افزوده‌شدن حذف یا پیش‌نویس شده، از خروجی بیرون
 * می‌رود و از متا هم پاک می‌شود — وگرنه فهرست کاربر لینک ۴۰۴ نشان می‌داد.
 */
function cyh_rest_account_wishlist_get( $request ) {
	$user_id = cyh_customer_authenticate_request( $request );
	if ( is_wp_error( $user_id ) ) {
		return $user_id;
	}

	$items = [];
	$alive = [];
	foreach ( cyh_customer_wishlist_slugs( $user_id ) as $slug ) {
		$product = cyh_customer_find_product( $slug );
		if ( $product ) {
			$alive[] = $slug;
			$items[] = [ 'slug' => $slug, 'name' => $product->post_title ];
		}
	}
	update_user_meta( $user_id, CYH_WISHLIST_META, $alive );

	return rest_ensure_response( [ 'items' => $items ] );
}

function cyh_rest_account_wishlist_update( $request ) {
	$user_id = cyh_customer_authenticate_request( $request );
	if ( is_wp_error( $user_id ) ) {
		return $user_id;
	}

	$slug   = sanitize_title( (string) $request->get_param( 'slug' ) );
	$action = (string) $request->get_param( 'action' );
	$slugs  = cyh_customer_wishlist_slugs( $user_id );

	if ( 'add' === $action ) {
		if ( '' === $slug || ! cyh_customer_find_product( $slug ) ) {
			return new WP_Error( 'cyh_bad_product', 'این محصول پیدا نشد.', [ 'status' => 404 ] );
		}
		if ( ! in_array( $slug, $slugs, true ) ) {
			if ( count( $slugs ) >= CYH_WISHLIST_MAX ) {
				return new WP_Error( 'cyh_wishlist_full', 'فهرست علاقه‌مندی‌ها پر است.', [ 'status' => 400 ] );
			}
			$slugs[] = $slug;
		}
	} elseif ( 'remove' === $action ) {
		$slugs = array_values( array_diff( $slugs, [ $slug ] ) );
	} else {
		return new WP_Error( 'cyh_bad_action', 'عملیات نامعتبر.', [ 'status' => 400 ] );
	}

	update_user_meta( $user_id, CYH_WISHLIST_META, $slugs );
	return rest_ensure_response( [ 'success' => true, 'slugs' => $slugs ] );
}

/** آدرس فرانت‌اند Astro — برای ساختن لینک بازیابی رمز در ایمیل. */
function cyh_get_frontend_url() {
	$origins = function_exists( 'cyh_get_allowed_origins' ) ? cyh_get_allowed_origins() : [];
	return $origins[0] ?? 'https://craneyadak.com';
}

function cyh_rest_account_saved_clear( $request ) {
	$user_id = cyh_customer_authenticate_request( $request );
	if ( is_wp_error( $user_id ) ) {
		return $user_id;
	}
	delete_user_meta( $user_id, CYH_SAVED_CHECKOUT_META );
	return rest_ensure_response( [ 'success' => true ] );
}

/* =========================================================================
   پنل وردپرس: «کاربران» فقط نام و ایمیل نشان می‌داد
   ========================================================================= */
/** تعداد سفارش پرداخت‌شده‌ی کاربر — شمارش در پایگاه‌داده، نه بارکردن همه (ستون «کاربران» برای هر ردیف صدا می‌زند). */
function cyh_user_paid_order_count( $user_id = 0 ) {
	return cyh_count_posts(
		[
			'post_type'   => CYH_QUOTE_CPT,
			'post_status' => 'publish',
			'author'      => (int) $user_id,
			'meta_query'  => [ [ 'key' => 'cyh_payment', 'value' => 'paid' ] ], // phpcs:ignore WordPress.DB.SlowDBQuery
		]
	);
}

function cyh_users_columns( $columns ) {
	$columns['cyh_phone']   = 'موبایل';
	$columns['cyh_company'] = 'شرکت';
	$columns['cyh_orders']  = 'سفارش پرداخت‌شده';
	return $columns;
}
add_filter( 'manage_users_columns', 'cyh_users_columns' );

function cyh_users_column_content( $value, $column, $user_id ) {
	if ( 'cyh_phone' === $column ) {
		$phone = (string) get_user_meta( $user_id, 'cyh_phone', true );
		return '' === $phone ? '—' : sprintf( '<a href="tel:%s" dir="ltr">%s</a>', esc_attr( $phone ), esc_html( $phone ) );
	}
	if ( 'cyh_company' === $column ) {
		return esc_html( (string) get_user_meta( $user_id, 'cyh_company', true ) ?: '—' );
	}
	if ( 'cyh_orders' === $column ) {
		$count = cyh_user_paid_order_count( $user_id );
		return $count > 0
			? sprintf( '<a href="%s">%d</a>', esc_url( admin_url( 'edit.php?post_type=' . CYH_QUOTE_CPT . '&cyh_view=orders&author=' . (int) $user_id ) ), $count )
			: '0';
	}
	return $value;
}
add_filter( 'manage_users_custom_column', 'cyh_users_column_content', 10, 3 );

/** بخش فقط‌خواندنی «مشخصات مشتری» در صفحه‌ی ویرایش کاربر. */
function cyh_user_profile_section( $user ) {
	$phone   = (string) get_user_meta( $user->ID, 'cyh_phone', true );
	$company = (string) get_user_meta( $user->ID, 'cyh_company', true );
	$saved   = cyh_checkout_saved( (int) $user->ID );
	$addr    = is_array( $saved ) ? implode( '، ', array_filter( [ $saved['customer']['province'] ?? '', $saved['customer']['city'] ?? '', $saved['customer']['address'] ?? '' ] ) ) : '';
	echo '<h2>مشخصات مشتری (کرین یدک)</h2><table class="form-table" role="presentation">';
	printf( '<tr><th>موبایل</th><td dir="ltr" style="text-align:right">%s</td></tr>', esc_html( '' === $phone ? '—' : $phone ) );
	printf( '<tr><th>شرکت</th><td>%s</td></tr>', esc_html( '' === $company ? '—' : $company ) );
	printf( '<tr><th>سفارش پرداخت‌شده</th><td>%d</td></tr>', cyh_user_paid_order_count( $user->ID ) );
	printf( '<tr><th>نشانی ذخیره‌شده</th><td>%s</td></tr>', esc_html( '' === $addr ? '—' : $addr ) );
	echo '</table>';
}
add_action( 'show_user_profile', 'cyh_user_profile_section' );
add_action( 'edit_user_profile', 'cyh_user_profile_section' );
